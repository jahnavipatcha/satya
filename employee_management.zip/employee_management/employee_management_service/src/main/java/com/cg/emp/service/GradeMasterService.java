package com.cg.emp.service;

import com.cg.emp.entities.GradeMaster;

public interface GradeMasterService {

	
	public GradeMaster addGradeMaster(GradeMaster grademaster);
}
